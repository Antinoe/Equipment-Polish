﻿using System;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ID;

namespace EquipmentPolish.Items
{
	public class EquipmentPolishKit : ModItem
	{
		public override void SetStaticDefaults()
		{
			DisplayName.SetDefault("Equipment Polishing Kit");
			Tooltip.SetDefault("Right Click any kind of Equipment with this item in hand to grant it a random prefix.");
		}

		public override void SetDefaults()
		{
			Item.width = 38;
			Item.height = 32;
			Item.maxStack = 30;
			Item.rare = 4;
			Item.value = 0;
		}

		public override void AddRecipes()
        {
			CreateRecipe(30)
            .AddIngredient(ItemID.ArmorPolish, 1)
            .Register();
			
			CreateRecipe(1)
            .AddIngredient(ItemID.SilverCoin, 25)
            .Register();
        }
	}
}
